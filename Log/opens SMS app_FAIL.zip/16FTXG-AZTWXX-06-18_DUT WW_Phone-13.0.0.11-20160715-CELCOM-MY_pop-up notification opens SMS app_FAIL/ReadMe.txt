08-14 17:24:40.959750   943  1561 V WindowManager: findFocusedWindow: Found new focus @ 9 = Window{870a3f5 u0 com.google.android.apps.messaging/com.google.android.apps.messaging.ui.ClassZeroActivity}
08-14 17:24:40.960144   943  1561 D PowerManagerService: acquireWakeLockInternal: lock=29825325, flags=0x1, tag="*launch*", ws=WorkSource{10062}, uid=1000, pid=943
08-14 17:24:40.960225   943  1561 D PowerManagerService: updateWakeLockSummaryLocked: mWakefulness=Awake, mWakeLockSummary=0x1
08-14 17:24:40.960279   943  1561 D PowerManagerService: updateUserActivitySummaryLocked: mWakefulness=Awake, mUserActivitySummary=0x9, nextTimeout=9318678 (in 6744 ms)
08-14 17:24:40.960358   943  1561 D DisplayPowerController: requestPowerState: policy=BRIGHT, useProximitySensor=false, screenBrightness=102, screenAutoBrightnessAdjustment=0.8, brightnessSetByUser=true, useAutoBrightness=true, blockScreenOn=false, lowPowerMode=false, boostScreenBrightness=false, dozeScreenBrightness=-1, dozeScreenState=UNKNOWN, waitForNegativeProximity=false
08-14 17:24:40.960398   943  1561 I PowerManagerService: setBrightness mButtonLight, screenBrightness=102
08-14 17:24:40.960439   943  1561 D PowerManagerService: updateDisplayPowerStateLocked: mDisplayReady=true, policy=3, mWakefulness=1, mWakeLockSummary=0x1, mUserActivitySummary=0x9, mBootCompleted=true, mScreenBrightnessBoostInProgress=false
08-14 17:24:40.960491   943  1561 D PowerManagerService: Acquiring suspend blocker "PowerManagerService.WakeLocks".
08-14 17:24:40.960559   943  1561 D PowerManagerNotifier: onWakeLockAcquired: flags=1, tag="*launch*", packageName=android, ownerUid=1000, ownerPid=943, workSource=WorkSource{10062}
08-14 17:24:40.961598   943  1407 V InputMethodManagerService: windowGainedFocus: android.os.BinderProxy@c425107 controlFlags=#104 softInputMode=#120 windowFlags=#1800002
08-14 17:24:40.962670 21985 21985 D ActivityThread: ACT-AM_ON_PAUSE_CALLED ActivityRecord{e9fcd6c token=android.os.BinderProxy@8298f35 {com.google.android.apps.messaging/com.google.android.apps.messaging.ui.ClassZeroActivity}}
08-14 17:24:40.965079   943  8456 W WindowManager:  SLCODE computeScreenConfigurationLocked, the hard device name is: himax-touchscreen
08-14 17:24:40.965144   943  8456 W WindowManager:  SLCODE computeScreenConfigurationLocked, the hard device name is: mtk-tpd
08-14 17:24:40.965170   943  8456 W WindowManager:  SLCODE computeScreenConfigurationLocked, the hard device name is: madev
08-14 17:24:40.965192   943  8456 W WindowManager:  SLCODE computeScreenConfigurationLocked, the hard device name is: ACCDET
08-14 17:24:40.965215   943  8456 W WindowManager:  SLCODE computeScreenConfigurationLocked, the hard device name is: otgid
08-14 17:24:40.965238   943  8456 W WindowManager:  SLCODE computeScreenConfigurationLocked, the hard device name is: mtk-kpd
08-14 17:24:40.966223   943  8456 D WindowManager: notifyActivityDrawnForKeyguard: waiting=false Callers=com.android.server.am.ActivityStackSupervisor.notifyActivityDrawnForKeyguard:452 com.android.server.am.ActivityStack.completeResumeLocked:1270 com.android.server.am.ActivityStack.resumeTopActivityInnerLocked:2355 com.android.server.am.ActivityStack.resumeTopActivityLocked:1824 com.android.server.am.ActivityStackSupervisor.resumeTopActivitiesLocked:3157 
08-14 17:24:40.969358   943  8456 V WindowManager: Looking for focus: 14 = Window{52cf07f u0 StatusBar}, flags=-2122055608, canReceive=false
08-14 17:24:40.969465   943  8456 V WindowManager: findFocusedWindow: Found new focus @ 8 = Window{2750bd7 u0 com.google.android.apps.messaging/com.google.android.apps.messaging.ui.conversation.ConversationActivity}